﻿function Create-FolderLocation{
param(
    [Parameter(Mandatory)]
    [string]$ArchiveDate
    )
    #$DestinationRoot = "\\scitw701\Visidot\Reader_Root\Photos\"
    $DestinationRoot = "C:\TEMP\Test\"
    $ArchivePath = $DestinationRoot + $ArchiveDate
    if (-not(Test-Path -Path $ArchivePath)){
        Write-Host "$ArchivePath does not exist"
        # Create folder
        New-Item -Path $ArchivePath -ItemType "Directory"
    }else{
        Write-Host "Folder Present"
    }
}

$ArchiveDate = Get-Date -Format "yyyy_MM"
Create-FolderLocation -ArchiveDate $ArchiveDate
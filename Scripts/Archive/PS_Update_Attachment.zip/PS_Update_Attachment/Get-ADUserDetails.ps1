﻿$OutputObject = New-Object System.Collections.ArrayList
$UserNames = Get-ADUser -SearchBase 'OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' -Properties Name, EmailAddress, UserPrincipalName, LastLogonDate, LockedOut, LogonCount, Enabled, HomeDirectory, Title, WhenCreated,WhenChanged, PasswordNeverExpires -Filter * | 
    Sort-Object Name
foreach ($User in $UserNames){
    $AccountDetail=New-Object psobject
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name UserName -value $User.Name
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name EmailAddress -value $User.EmailAddress
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name UserPrincipalName -value $User.UserPrincipalName
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name LastLogonDate -value $User.LastLogonDate
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name Enabled -value $User.Enabled
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name LockedOut -value $User.LockedOut
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name LogonCount -value $User.LogonCount
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name HomeDirectory -value $User.HomeDirectory
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name Title -value $User.Title
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name WhenCreated -value $User.WhenCreated
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name WhenChanged -value $User.WhenChanged
    Add-Member -Inputobject $AccountDetail -MemberType noteProperty -name PasswordNeverExpires -value $User.PasswordNeverExpires
    $OutputObject.Add($AccountDetail) | Out-Null
    # Name, EmailAddress, UserPrincipalName, LastLogonDate, Enabled, HomeDirectory, Title, WhenCreated,WhenChanged, PasswordNeverExpires
}
$OutputObject | Export-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\20200825_UserList.csv -NoTypeInformation

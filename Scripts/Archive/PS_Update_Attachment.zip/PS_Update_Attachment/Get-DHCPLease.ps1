﻿################################################################################
#
# Get All DHCP Lease information from Server
#
################################################################################

$dhcpServerName = 'seachdc1' # Change this to be a parameter
$dhcpScopeList = Get-DhcpServerv4Scope -ComputerName $dhcpServerName

foreach ($scope in $dhcpScopeList){
    Get-DhcpServerv4ScopeStatistics -ComputerName $dhcpServerName -ScopeId $scope.ScopeId.ToString()
    Get-DhcpServerv4Lease -ComputerName $dhcpServerName -ScopeId $scope.ScopeId.ToString() | Select IPaddress, Hostname, ClientId, AddressState, ClientType |Format-Table
}



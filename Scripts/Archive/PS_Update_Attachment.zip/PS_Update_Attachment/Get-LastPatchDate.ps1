﻿#####
#
# Get-LastPatchDate.ps1
#
#####
#
# Queries AD for a list of computers in a specified OU then checks each computer for the date it last 
# installed updates. Once this is complete the output object can be emailed.
#
#####

# Get computer list from AD
$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$ServerList = Get-ADComputer -Filter * -SearchBase $Base -Properties Name, OperatingSystem, Description | Sort-Object Name

# Create output object
$OutputObj = New-Object System.Collections.ArrayList

## Debug file details ## an error log file to see if there is any exception raised when trying to get the last patch date when script is scheduled
$CurrentDate = Get-Date -Format "yyyyMMdd"
$ErrorLogFile = "C:\PS_Update_Attachment\LastUpdate" + $CurrentDate + ".log"

# Run through each computer in the list and check if it's online and if it is then check the last update date
foreach ($Server in $ServerList){
    if ($true -eq $Server.Enabled){ # Removes disabled Servers - these will be powered off or decommissioned
        $CurrentServer = New-Object PSObject # creates a temporary object to hold the details of the current server
        
    # Test the computer is it online?
        if (Test-Connection -ComputerName $Server.Name -Quiet -Count 1){ # Online
            $ServerStatus = "Online"
            # Get the last patched details

            try{
                $lastpatch = Get-WmiObject -ComputerName $Server.Name Win32_Quickfixengineering | 
                    select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | 
                    select-object -property installedon -last 1
                    $LogContent = (Get-Date -Format "yyyyMMdd-HH:mm:ss") + " - " + $lastpatch
                    Add-Content -Path $ErrorLogFile -Value $LogContent
                $LastPatchDate = Get-Date $lastpatch.InstalledOn -format yyyy-MM-dd
            } catch {
                $Error = $_.Exception
                $ErrorDetals = $_.ErrorDetails
                Add-Content -Path $ErrorLogFile -Value $Error
                Add-Content -Path $ErrorLogFile -Value $ErrorDetals
                Add-Content -Path $ErrorLogFile -Value ""
                $LastPatchDate = "Error"
            }
        } else {
            $ServerStatus = "Offline"
            $LastPatchDate = Get-Date '1900-01-01' -Format yyyy-MM-dd # Use a default date for offline servers
        }

        # Build the current server object
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Name -Value $Server.Name
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name OS -value $Server.OperatingSystem
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name Description -value $Server.Description
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name LastPatchDate -value $LastPatchDate
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Status -Value $ServerStatus
        
        # Add the current server to the final output object
        $OutputObj.add($CurrentServer)|Out-Null
    }
}

#Build the email
$EmailServer = 'UKGMBSSMTP01.int.hiltonfoods.com'
#$Recipients = 'italerts@HFGPLC.com'
$Recipients = 'Wayne.Arliss@HFGPLC.com'
$Sender = 'UKGMB-Automated@hfgplc.com'
$Subject = '[Automated] Server Last Patched Date information'
$Body = 'See attached file.'
$AttachmentFile = 'C:\PS_Update_Attachment\ServerUpdate.csv'
$OutputObj | Export-Csv -Path $AttachmentFile -NoTypeInformation

Send-MailMessage -SmtpServer $EmailServer -To $Recipients -From $Sender -Subject $Subject -Body $Body -Attachments $AttachmentFile
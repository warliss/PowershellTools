﻿#####
#
# Get-LastPatchDate.ps1
#
#####
#
# Queries AD for a list of computers in a specified OU then checks each computer for the date it last 
# installed updates. Once this is complete the output object can be emailed.
#
#####

# Get computer list from AD
$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$ServerList = Get-ADComputer -Filter * -SearchBase $Base -Properties Name, OperatingSystem, Description | Sort-Object Name

# Create output object
$OutputObj = New-Object System.Collections.ArrayList

# Run through each computer in the list and check if it's online and if it is then check the last update date
foreach ($Server in $ServerList){
    #$Server.Name
    $CurrentServer = New-Object PSObject
    Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Name -Value $Server.Name
    Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name OS -value $Server.OperatingSystem
    Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name Description -value $Server.Description

    # Test the computer is online
    if (Test-Connection -ComputerName $Server.Name -Quiet -Count 1){
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Status -Value "Online"
        $lastpatch = Get-WmiObject -ComputerName $Server.Name Win32_Quickfixengineering | 
            select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | 
            select-object -property installedon -last 1
        $LastPatchDate = Get-Date $lastpatch.InstalledOn -format yyyy-MM-dd
    } else {
        $LastPatchDate = Get-Date '1900-01-01' -Format yyyy-MM-dd
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Status -Value "Offline"
    }
    
    Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name LastPatchDate -value $LastPatchDate
    
    # Add the server details to the output object
    $OutputObj.add($CurrentServer) | Out-Null
}

#Build the email
$EmailServer = 'UKGMBSSMTP01.int.hiltonfoods.com'
#$Recipients = 'italerts@HFGPLC.com'
$Recipients = 'Wayne.Arliss@HFGPLC.com'
$Sender = 'UKGMB-Automated@hfgplc.com'
$Subject = '[Automated] Server Last Patched Date information'
$Body = 'See attached file.'
$AttachmentFile = 'C:\PS_Update_Attachment\ServerUpdate.csv'
$OutputObj | Export-Csv -Path $AttachmentFile -NoTypeInformation

Send-MailMessage -SmtpServer $EmailServer -To $Recipients -From $Sender -Subject $Subject -Body $Body -Attachments $AttachmentFile





﻿$ComputerList = 'seachw009'#,'seachw175','seachw150'
$OutputObj = New-Object System.Collections.ArrayList
foreach ($ComputerName in $ComputerList){
    $Printers = Get-WMIObject -Class Win32_Printer -ComputerName $ComputerName
    $CurrentComputer = New-Object System.Collections.ArrayList
    foreach ($Printer in $Printers){
        $CurrentPrinter = New-Object System.Collections.ArrayList
        Add-Member -Inputobject $CurrentPrinter -MemberType noteProperty -name Computer -value $Printer.SystemName
        Add-Member -InputObject $CurrentPrinter -MemberType NoteProperty -Name Name -Value $Printer.Name
        Add-Member -Inputobject $CurrentPrinter -MemberType noteProperty -name Default -value $Printer.Default
        Add-Member -Inputobject $CurrentPrinter -MemberType noteProperty -name State -value $Printer.State
        Add-Member -Inputobject $CurrentPrinter -MemberType noteProperty -name Status -value $Printer.Status
        $CurrentComputer.add($CurrentPrinter)|Out-Null
        }
    $OutputObj.add($CurrentComputer)|Out-Null
    }
    $OutputObj | Out-GridView
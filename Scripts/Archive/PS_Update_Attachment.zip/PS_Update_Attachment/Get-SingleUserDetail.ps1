﻿## Query User password details
$userName = "Wayne.Arliss_UKGMBAD"
$userDetails = Get-ADUser -Identity $userName -Properties *

$DaysSinceLastSet = (New-TimeSpan -Start $userDetails.PasswordLastSet -End (Get-Date -Format dd/MM/yyyy)).Days


$outputObj = New-Object PSObject
Add-Member -InputObject $outputObj -MemberType NoteProperty -Name User -Value $userDetails.DisplayName
Add-Member -Inputobject $outputObj -MemberType noteProperty -name PasswordNeverExpires -value $userDetails.PasswordNeverExpires
Add-Member -Inputobject $outputObj -MemberType noteProperty -name PasswordLastSet -value $userDetails.PasswordLastSet
Add-Member -Inputobject $outputObj -MemberType noteProperty -name LastAccountupdate -value $userDetails.whenChanged
Add-Member -InputObject $outputObj -MemberType NoteProperty -Name DaysSinceLastSet -Value $DaysSinceLastSet

##PasswordNeverExpires

$outputObj | Out-GridView -Title $userName
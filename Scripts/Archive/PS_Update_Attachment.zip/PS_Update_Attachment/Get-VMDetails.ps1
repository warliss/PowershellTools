﻿# Connect to VSphere server
#Connect-VIServer -Server seavc.seachill.co.uk 

# Create output object
$OutputObj = New-Object System.Collections.ArrayList

$VMs = Get-VM
foreach ($VM in $VMs){
    $CurrentVM = New-Object psobject
    $OSFamily = ''
    if ($VM.Guest.GuestFamily -eq 'windowsGuest'){
        $OSFamily = 'Microsoft Windows'
    } elseif ($VM.Guest.GuestFamily -eq 'linuxGuest') {
        $OSFamily = 'Linux'
    } else {
        $OSFamily = 'Unknown'
    }
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name VMName -Value $VM.Name
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name CPUs -Value $VM.NumCPU
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name OS -Value $VM.Guest.OSFullName
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name OSFamily -Value $OSFamily
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name MemoryGB -Value $VM.MemoryGB
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name PowerState -Value $VM.PowerState
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name HardwareVersion -Value $VM.HardwareVersion
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name ToolsVersion -Value $VM.Guest.ToolsVersion
    <#
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name VMName -Value $VM.Name
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name VMName -Value $VM.Name
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name VMName -Value $VM.Name
    #>
    $OutputObj.add($CurrentVM)|Out-Null
}
$OutputObj | Sort-Object VMName | Export-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\20201012_VMDetails.csv -NoTypeInformation # | Out-GridView
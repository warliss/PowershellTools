﻿$AdminAccountDetails = New-Object System.Collections.ArrayList
$AdminUsers = 'Wayne.Arliss_UKGMBAD', 'chris.marchant_ukgmb', 'dave.hagan_ukgmbadmi', 'mark.radley_ukgmbad', 'steve.wallace_ukgmba', 'tim.knight_ukgmbad', 'tony.aisthorpe_ukgmb'
#$AdminUsers = 'Wayne.Arliss', 'chris.marchant', 'Howard.Dingwall'
foreach ($AdminUser in $AdminUsers){
    $UserDetails = Get-ADUser -Identity $AdminUser -Properties *
    $AdminAccountDetail = New-Object psobject
    $PasswordExpireDate = $UserDetails.PasswordLastSet.AddDays(60)
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name UserName -value $UserDetails.Name
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name AccountName -value $UserDetails.SamAccountName
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name PasswordExpired -value $UserDetails.PasswordExpired
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name PasswordLastSet -value $UserDetails.PasswordLastSet
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name PasswordExpireDate -value $PasswordExpireDate
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name LastLogonDate -value $UserDetails.LastLogonDate
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name Enabled -value $UserDetails.Enabled
    Add-Member -Inputobject $AdminAccountDetail -MemberType noteProperty -name LockedOut -value $UserDetails.LockedOut
    $AdminAccountDetails.Add($AdminAccountDetail) | Out-Null
}

$AdminAccountDetails| Sort-Object PasswordExpireDate | Out-GridView
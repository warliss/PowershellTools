﻿$AllUsers = Get-ADUser -Filter * -Properties Name,Created,SamAccountName, HomeDirectory -SearchBase 'OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' |Select Name,Created,SamAccountName, HomeDirectory

# Create output object
$OutputObj = New-Object System.Collections.ArrayList



foreach ($User in $AllUsers){
    $CurrentUser = New-Object PSObject # creates a temporary object to hold the details
    $HDMissing = "Missing"
    if (Test-Path -Path ($User.HomeDirectory)){
        #Write-Host $User.Name " Exists"
        $HDMissing = "Exists"
    } else {
        
        Write-Host $User.Name " Path does not exist"
        $HDMissing = "Missing"
    }
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Name -Value $User.Name
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name CreateDate -value $User.Created
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name SAMAccountName -value $User.SamAccountName
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name HomeDirectory -value $User.HomeDirectory
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Status -Value $HDMissing
    $OutputObj.add($CurrentUser)|Out-Null
}

﻿## Functions first
function Get-UserList{ # Get AD users from specific OU - $Scope - and return an object
param([Parameter(Mandatory)][string]$Scope)
    $List = Get-ADUser -Filter * -SearchBase $Scope -Properties HomeDirectory |Sort-Object Name
    return $List
}

function SetOutput{ # 
    [CmdletBinding()]
    param ( 
        [Parameter(Mandatory)][string]$Folder,
        [Parameter(Mandatory)][string]$UState,
        [Parameter(Mandatory)][string]$FState,
        [string]$Notes = "")
    Write-Verbose ("Folder $Folder UserState $UState FolderState $FState Note $Notes")
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Folder -Value $Folder
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name UserState -Value $UState
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name FolderState -Value $FState
    Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Notes -Value $Notes
}

## Get a list of current Users and their drive mapping
$ActiveBase = 'OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## UKGMB Users
$ActiveUserList = Get-UserList -Scope $ActiveBase

## Get a list of disabled users and their drive mapping
$InactiveBase = 'OU=Disabled Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## UKGMB Disabled Users
$InactiveUserList = Get-UserList -Scope $InactiveBase

## Get the list of all directories in \\SEACHFS1\Users and compare with the user list
$HomeLocation = '\\seachfs1\Users\'
$UserFolders =  Get-ChildItem -Path $HomeLocation -Directory
$OutputList = New-Object System.Collections.ArrayList

foreach ($Folder in $UserFolders){
    $CurrentUser = New-Object PSObject # creates a temporary object to hold the details of the current User
    $CurrentFolder = $Folder.FullName

    if ($InactiveUserList.HomeDirectory -contains $CurrentFolder){
        $isInactive = 1
        $isActive = 0
        SetOutput -Folder $CurrentFolder -UState "Inactive" -FState "Folder Present" -Notes "User is disabled and folder present"
    } else {
        if ($ActiveUserList.HomeDirectory -contains $CurrentFolder){
            $isInactive = 0
            $isActive = 1
            SetOutput -Folder $CurrentFolder -UState "Active" -FState "Folder Present"
        } else {
            $isInactive = 0
            $isActive = 0
            SetOutput -Folder $CurrentFolder -UState "Inactive" -FState "Folder Present"
        }
    }
    $OutputList.add($CurrentUser)|Out-Null 
    #Write-Host $CurrentFolder "Is Active" $isActive "Is Inactive" $isInactive
}
$OutputList | Out-GridView
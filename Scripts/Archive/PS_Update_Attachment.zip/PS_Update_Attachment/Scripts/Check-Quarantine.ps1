﻿# Connect to Exchange Online
$EXO_Cred = Get-Credential -Message 'Please enter your Exchange Online credentials'
Connect-ExchangeOnline -Credential $EXO_Cred

# Get quarantined messages between two dates
$Now = Get-Date
[System.DateTime]$StartDate = $Now.AddDays(-7) #"2022-11-30"
[System.DateTime]$EndDate = $Now #"2022-12-1"

# Output object
$OutputData = New-Object System.Collections.ArrayList

$SenderAddress = "noreply@jotform.com"

$QuarantinedMessages = Get-QuarantineMessage -StartReceivedDate $StartDate -EndReceivedDate $EndDate -ReleaseStatus 'NOTRELEASED' -PageSize 1000 -Page 1 -SenderAddress $SenderAddress
if ($QuarantinedMessages.Count -gt 0){
    # Not outputting a count to screen compile a CSV with some of the details in.
    foreach ($QMessage in $QuarantinedMessages){
        $CurrentMsg = New-Object psobject
        # build temporary object to be added to the $OutputData final object
        Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name User -Value $QMessage.RecipientAddress
        Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name Received -Value $QMessage.ReceivedTime
        Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name Expires -Value $QMessage.Expires
        Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name Sender -Value $QMessage.SenderAddress
        Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name Subject -Value $QMessage.Subject
        #Add-Member -InputObject $CurrentMsg -MemberType NoteProperty -Name Status -Value $QMessage.ReleasedStatus
        $OutputData.add($CurrentMsg)|Out-Null
    }
}
$OutputData | Out-GridView
$OutputData | Export-Csv -Path 'C:\Users\Wayne.Arliss_UKGMBAD\Desktop\qEmails.csv' -NoTypeInformation
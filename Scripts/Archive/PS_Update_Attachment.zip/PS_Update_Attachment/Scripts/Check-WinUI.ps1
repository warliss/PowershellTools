﻿$OutputObj = New-Object System.Collections.ArrayList

function CheckForError(){
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$True,Position=1)]
        [string]$RemoteComputer
    )
    $StartTime = (Get-Date).AddMinutes(-240) # Get a timestamp & take 4 hours off
    $LastError = Get-EventLog -ComputerName $RemoteComputer -LogName Application -Newest 1 -InstanceId 1026
    $LastErrorMessage = $LastError.Message
    $CurrentComputer = New-Object PSObject # creates a temporary object to hold the details of the current server
    if($LastErrorMessage.Contains('WinUI.exe')){
        Add-Member -InputObject $CurrentComputer -MemberType NoteProperty -Name Name -Value $RemoteComputer
        Add-Member -Inputobject $CurrentComputer -MemberType noteProperty -name Source -value $LastError.Source
        Add-Member -Inputobject $CurrentComputer -MemberType noteProperty -name Message -value 'WinUI.exe error'
        Add-Member -Inputobject $CurrentComputer -MemberType noteProperty -name TimeGenerated -value $LastError.TimeGenerated
    }
    $OutputObj.add($CurrentComputer)|Out-Null
}

function SendEmail(){
    $EmailServer = 'UKGMBSSMTP01.int.hiltonfoods.com'
    $Recipients = 'Wayne.Arliss@hfgplc.com'
    $Sender = 'UKGMB-Automated@hfgplc.com'
    $Subject = '[Automated] Innova Error Check'
    $Body = "Test Email"
    $Body += $OutputObj | select Name, Source, Message, TimeGenerated
    $Body += "End"
    ## Uncomment the next line to enable emailing.
    #Send-MailMessage -SmtpServer $EmailServer -To $Recipients -From $Sender -Subject $Subject -Body $Body 
}

$Computers= 'UKGMBCD1007','UKGMBCD1008','UKGMBCD1009'
foreach ($Computer in $Computers){
    CheckForError -RemoteComputer $Computer
}

$OutputObj
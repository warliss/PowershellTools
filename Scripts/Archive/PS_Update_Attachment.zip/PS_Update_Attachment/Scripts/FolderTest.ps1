﻿## Users

$Base = "OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com"
$Users = Get-ADUser -Filter * -SearchBase $Base |Sort-Object Name
#$Users.SamAccountName

## Home Drives
$HomeFolderBase = "\\seachfs1\Users\"
$Folders = Get-ChildItem -Directory -Path $HomeFolderBase |Sort-Object Name
#$Folders.Name
$TotalFolders = $Folders.Count
$NoDot = 0
$YesDot = 0
foreach ($Folder in $Folders){
    if ($Folder.Name.Contains('.')){
        #Write-Host ($Folder.Name) "Contains dot"
        $YesDot ++
        }else{
        #Write-Host ($Folder.Name) "No dot"
        $NoDot ++
        }
}

#$NoDotPercent = [math]::Round(($NoDot / $TotalFolders)*100,2)
#$YesDotPercent = [math]::Round(($YesDot / $TotalFolders)*100,2)
$NoDotPercent = ($NoDot / $TotalFolders).ToString("P")
$YesDotPercent = ($YesDot / $TotalFolders).ToString("P")


Write-Host " Total Folders:" $TotalFolders
Write-Host "Contains a Dot:" $YesDot $YesDotPercent
Write-Host " Without a Dot:" $NoDot $NoDotPercent

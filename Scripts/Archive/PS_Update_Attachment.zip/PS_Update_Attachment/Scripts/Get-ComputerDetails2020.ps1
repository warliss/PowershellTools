﻿$reportedvms=New-Object System.Collections.ArrayList
$vms=get-view -viewtype virtualmachine  | 
    Sort-Object -Property {  $_.Config.Hardware.Device |  
        where {$_ -is [VMware.Vim.VirtualEthernetCard]} |  
    Measure-Object | 
    select -ExpandProperty Count} -Descending
 
foreach($vm in $vms){
    $reportedvm = New-Object PSObject
    Add-Member -Inputobject $reportedvm -MemberType noteProperty -name Guest -value $vm.Name
    Add-Member -Inputobject $reportedvm -MemberType noteProperty -name FQDN -value $vm.Guest.HostName
    Add-Member -Inputobject $reportedvm -MemberType noteProperty -name OS -value $vm.Guest.GuestFullName
    Add-Member -Inputobject $reportedvm -MemberType noteProperty -name PoweredStatus -value $vm.Guest.GuestState
    Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name MemoryTotal -Value $vm.Summary.Config.MemorySizeMB
    #Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name MemoryTotal -Value $vm.Summary.Config.MemorySizeMB
    
    # Getting the VM hostname
    $VMHost = (Get-VM -Name $vm.Name).VMHost.Name
    Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name VMHost -Value $VMHost
    $networkcards=$vm.guest.net | ?{$_.DeviceConfigId -ne -1}
    $i=0
    foreach($ntwkcard in $networkcards){
        Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name "networkcard${i}.Network" -Value $ntwkcard.Network
        Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name "networkcard${i}.MacAddress" -Value $ntwkcard.Macaddress
        Add-Member -InputObject $reportedvm -MemberType NoteProperty -Name "networkcard${i}.IpAddress" -Value $($ntwkcard.IpAddress|?{$_ -like "*.*"})
        $i++
    }
    $reportedvms.add($reportedvm)|Out-Null
}

$reportedvms | Sort-Object VMHost, Guest | Export-Csv C:\Users\Wayne.Arliss_UKGMBAD\Desktop\VMList_20200703.csv -NoTypeInformation

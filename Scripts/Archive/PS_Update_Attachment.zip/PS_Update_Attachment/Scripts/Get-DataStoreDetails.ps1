﻿##
# Set up output details
$DataStoreOutputObj = New-Object System.Collections.ArrayList

##
# Get credentials to be used 
# $VMCredentials = Get-Credential -Message 'Please enter the account to access vSphere' # Uncomment first time running

##
# vSphere Server details
#$vSphereServer = 'seavc.seachill.co.uk' # UKGMB LFR VSA vSphere
$vSphereServer = 'ukgmbesvca01.int.hiltonfoods.com' # UKI SVT vSphere
# Connect to the vSphere server
$vSphereServerConnection = Connect-VIServer -Server $vSphereServer -Credential $VMCredentials

##
# Get datastore detials - What is needed
# Name, State, Type, ParentFolder, Datacenter, CapacityMB, FreeSpaceMB
$DataStores = Get-Datastore -Server $vSphereServer
foreach ($DataStore in $DataStores){
    $CurrentStore = New-Object PSObject # creates a temporary object to hold the details of the current VM
    $StoreDetails = Get-Datastore -Name $DataStore
    Add-Member -InputObject $CurrentStore -MemberType NoteProperty -Name Name -Value $StoreDetails.Name
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name State -value $StoreDetails.State
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name Type -value $StoreDetails.Type
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name ParentFolder -value $StoreDetails.ParentFolder
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name DataCenter -value $StoreDetails.DataCenter
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name CapacityMB -value $StoreDetails.CapacityMB
    Add-Member -Inputobject $CurrentStore -MemberType noteProperty -name FreeSpaceMB -value $StoreDetails.FreeSpaceMB
    $DataStoreOutputObj.add($CurrentStore)|Out-Null
}


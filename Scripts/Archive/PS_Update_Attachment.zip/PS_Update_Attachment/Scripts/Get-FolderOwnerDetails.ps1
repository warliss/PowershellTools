﻿$UserHome = '\\SEACHFS1\Users'
$UserFolders = Get-ChildItem -Path $UserHome -Directory
$OutputObj = New-Object System.Collections.ArrayList
foreach ($Folder in $UserFolders){
    $Owner = Get-NTFSOwner -Path $Folder.FullName
    $Inheritance = $Folder.IsInheritanceBlocked
    $FolderAccess = Get-NTFSAccess -Path $Folder.FullName
    foreach ($Access in $FolderAccess){
        $CurrentFolder = New-Object psobject
        Add-Member -InputObject $CurrentFolder -MemberType NoteProperty -Name Name -Value $Folder.FullName
        Add-Member -InputObject $CurrentFolder -MemberType NoteProperty -Name Owner -Value $Owner.Owner
        Add-Member -InputObject $CurrentFolder -MemberType NoteProperty -Name Account -Value $Access.Account
        Add-Member -InputObject $CurrentFolder -MemberType NoteProperty -Name AccessRights -Value $Access.AccessRights
        Add-Member -InputObject $CurrentFolder -MemberType NoteProperty -Name IsInhertanceBlocked -Value $Inheritance
        $OutputObj.add($CurrentFolder)|Out-Null
    }
}
$OutputObj |Out-GridView

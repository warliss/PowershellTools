﻿#####
#
# Get-LAPSStatus.ps1
#
# Author: Wayne Arliss - Wayne.Arliss@hfgplc.com
#
# Version: 1.0
#
#####
#
# Queries AD for a list of computers in a specified OU then checks each computer to check if LAPS is
# installed.
#
#####

# Get computer list from AD
$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## UKGMB Servers 
#$Base = 'OU=Servers,OU=HFGIE,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## IEDRG Servers 
#$Base = 'OU=Production,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Omega Touchscreens
$ServerList = Get-ADComputer -Filter * -SearchBase $Base -Properties * | Sort-Object Name

foreach ($Computer in $ServerList){
    if (Test-Connection -ComputerName $Computer.Name -Quiet -Count 1){
        if (Get-Member -inputobject $Computer -name "ms-Mcs-AdmPwd" -MemberType Properties) {
            #Property Exists
            Write-Host $Computer.Name "LAPS" $Computer.Enabled
        }else{
            Write-Host -ForegroundColor Red ($Computer.Name) "None"
        }
    }
}
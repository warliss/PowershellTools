﻿#####
#
# Get-LastPatchDate.ps1
#
# Author: Wayne Arliss - Wayne.Arliss@hfgplc.com
#
# Version: 1.0
#
#####
#
# Queries AD for a list of computers in a specified OU then checks each computer for the date it last 
# installed updates. Once this is complete the output object can be emailed.
#
#####

# Get computer list from AD
$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## UKGMB Servers 
#$Base = 'OU=Servers,OU=HFGIE,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## IEDRG Servers 
#$Base = 'OU=Production,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Omega Touchscreens
$ServerList = Get-ADComputer -Filter * -SearchBase $Base -Properties Name, OperatingSystem, Description, Enabled | Sort-Object Name

## Debug file details ## an error log file to see if there is any exception raised when trying to get the last patch date when script is scheduled
$CurrentDate = Get-Date -Format "yyyyMMdd"
$ErrorLogFile = "C:\PS_Update_Attachment\LastUpdate-" + $CurrentDate + ".log"

# Create output object
$OutputObj = New-Object System.Collections.ArrayList

## Progress bar variables
$TotalItems = $ServerList.Count
$CurrentItem = 0
$PercentComplete = 0

foreach ($Server in $ServerList){
    Write-Progress -Activity "Querying last patchdate" -Status "$PercentComplete Complete:" -PercentComplete $PercentComplete
    if ($true -eq $Server.Enabled){ # Removes disabled Servers - these will be powered off or decommissioned
        $CurrentServer = New-Object PSObject # creates a temporary object to hold the details of the current server
        
    # Test the computer is it online?
        if (Test-Connection -ComputerName $Server.Name -Quiet -Count 1){ # Online
            $ServerStatus = "Online"
            # Get the last patched details
            Write-Host ($Server.Name) "is" $ServerStatus
            try{
                $lastpatch = Get-WmiObject -ComputerName $Server.Name Win32_Quickfixengineering | 
                    select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | 
                    select-object -property installedon -last 1
                    $LogContent = (Get-Date -Format "yyyyMMdd-HH:mm:ss") + " - " + $lastpatch
                    Add-Content -Path $ErrorLogFile -Value $LogContent
                $LastPatchDate = Get-Date $lastpatch.InstalledOn -format yyyy-MM-dd
            }
            catch {
                $Error = $_.Exception
                $ErrorDetals = $_.ErrorDetails
                Add-Content -Path $ErrorLogFile -Value $Error
                Add-Content -Path $ErrorLogFile -Value $ErrorDetals
                Add-Content -Path $ErrorLogFile -Value ""
                $LastPatchDate = "Error"
            }
            Finally {
                #$LogContent = (Get-Date -Format "yyyyMMdd-hh:mm:ss") + "Ending"
                #Add-Content -Path $ErrorLogFile -Value $LogContent
            }
        } else {
            $ServerStatus = "Offline"
            $LastPatchDate = Get-Date '1900-01-01' -Format yyyy-MM-dd # Use a default date for offline servers
            Write-Host ($Server.Name) "is" $ServerStatus
        }

        # Build the current server object
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Name -Value $Server.Name
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name OS -value $Server.OperatingSystem
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name Description -value $Server.Description
        Add-Member -Inputobject $CurrentServer -MemberType noteProperty -name LastPatchDate -value $LastPatchDate
        Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name Status -Value $ServerStatus
        
        # Add the current server to the final output object
        $OutputObj.add($CurrentServer)|Out-Null
    }
    $CurrentItem++
    $PercentComplete = [int](($CurrentItem / $TotalItems) * 100)
}

# build email and attachment required
# Email details
$EmailServer = 'UKGMBSSMTP01.int.hiltonfoods.com'
$Recipients = 'Wayne.Arliss@hfgplc.com'
$Sender = 'UKGMB-Automated@hfgplc.com'
$Subject = '[Automated] Server Last Patched Date information'
$Body = "Test email"
#$Body += $OutputObj | Select-Object -Property Name,LastPatchDate
$AttachmentFile = 'C:\PS_Update_Attachment\ServerUpdate.csv'

$OutputObj | Export-Csv -Path $AttachmentFile -NoTypeInformation
## Display the results to screen, when automating comment the next line out.
$OutputObj | Out-GridView

## Uncomment the next line to enable emailing.
#Send-MailMessage -SmtpServer $EmailServer -To $Recipients -From $Sender -Subject $Subject -Body $Body  -Attachments $AttachmentFile

## Still to include in the file - switches to swap between emailed output and display to screen.
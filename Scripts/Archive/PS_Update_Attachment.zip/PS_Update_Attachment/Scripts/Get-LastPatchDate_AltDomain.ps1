﻿$ServerList = 'seachdc1', 'seachdc2', 'seachdb1', 'seachsage3', 'lmsrv', 'seachwsus1'
#$ServerList = 'seaacc', 'seaacronis1', 'seadc2', 'seadc3', 'seadimaco', 'seaexch', 'seaisys', 'seanps1', 'seaqpulse2', 'seasysint'
$Cred = Get-Credential
#$ServerList = 'seachwsus1'
foreach ($Server in $ServerList){
    $lastpatch = Get-WmiObject -Credential $Cred -ComputerName $Server Win32_Quickfixengineering | 
        select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | 
        select-object -property installedon -last 1
    $LastPatchDate = Get-Date $lastpatch.InstalledOn -format yyyy-MM-dd
    Write-Host "$Server # $LastPatchDate"
}



﻿# Server list
#$ServerList = 'ukgmbsqpl01', 'ukgmbsmes01'
$ServerList = "SEACHEARNIE", "SEACHFS1", "SEACHINNOVA1", "SEACHPRINT1", "UKGMBESARB01", "UKGMBSACS01", "UKGMBSCC01", "UKGMBSCC02", "UKGMBSCM01", "UKGMBSFS01", "UKGMBSMES01", "UKGMBSNPS01", "UKGMBSOME00", "UKGMBSOME01", "UKGMBSOME02", "UKGMBSOME03", "UKGMBSOME04", "UKGMBSOME05", "UKGMBSQCS02", "UKGMBSQPL01", "UKGMBSQVW01", "UKGMBSSI01", "UKGMBSSI02", "UKGMBSSMTP01", "UKGMBSWFM01"
## all servers "SEACHEARNIE", "SEACHFS1", "SEACHINNOVA1", "SEACHPRINT1", "UKGMBESARB01", "UKGMBSACS01", "UKGMBSCC01", "UKGMBSCC02", "UKGMBSCM01", "UKGMBSFS01", "UKGMBSMES01", "UKGMBSNPS01", "UKGMBSOME00", "UKGMBSOME01", "UKGMBSOME02", "UKGMBSOME03", "UKGMBSOME04", "UKGMBSOME05", "UKGMBSQCS02", "UKGMBSQPL01", "UKGMBSQVW01", "UKGMBSSI01", "UKGMBSSI02", "UKGMBSSMTP01", "UKGMBSWFM01"
# Create output object
$OutputObj = New-Object System.Collections.ArrayList

foreach ($Server in $ServerList){
    # Get logged in users
    $LoggedInUsers = qwinsta /Server:$Server
    $LineNumber = 0
    #find username
    foreach ($Line in $LoggedInUsers){
        if ($LineNumber -gt 0){
            $CurrentLine = New-Object PSObject

            $Session = $Line.Substring(1,18)
            $UN = $Line.substring(19,22)
            $SessionID = $Line.Substring(40,6)
            $SessionState = $Line.Substring(48,6)
            if (($UN.Trim()) -ne ""){
                # Build the current line object
                Add-Member -InputObject $CurrentLine -MemberType NoteProperty -Name ServerName -Value $Server
                Add-Member -InputObject $CurrentLine -MemberType NoteProperty -Name UserName -Value $UN.Trim()
                Add-Member -Inputobject $CurrentLine -MemberType noteProperty -name SessionName -value $Session.Trim()
                Add-Member -Inputobject $CurrentLine -MemberType noteProperty -name SessionID -value $SessionID.Trim()
                Add-Member -Inputobject $CurrentLine -MemberType noteProperty -name SessionState -value $SessionState.Trim()
                #$CurrentLine
                $OutputObj.add($CurrentLine)|Out-Null
            }
        }else{
            #$Server
        }
        $LineNumber++
    }
}
$OutputObj |FT
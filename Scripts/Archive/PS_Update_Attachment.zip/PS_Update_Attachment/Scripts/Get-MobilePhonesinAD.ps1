﻿$OU ='OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$ExportPath = $env:USERPROFILE + '\Desktop\mobilephonelist.csv'
Get-ADUser -SearchBase $OU -Properties TelephoneNumber, MobilePhone, Office -Filter * | 
    Select-Object Name, Office, TelephoneNumber, MobilePhone | 
    Sort-Object Name | 
    Out-GridView


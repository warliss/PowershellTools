﻿#####
# Setup O365 PS Session
###
$O365Cred = Get-Credential # Full standard user email address
$O365Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://ps.outlook.com/powershell/ -Credential $Cred -Authentication Basic -AllowRedirection
Import-PSSession $O365Session

#####
# Get UKGMB User list - if this is not done a full list of all users in the tennant is returned (Too many!)
###
$UKGMBOU = 'OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$UKGMBUsers = Get-ADUser -Filter * -SearchBase $UKGMBOU -Properties mail

#####
# Work through the list from AD to get Stats for all current users
###
# Create output object
###
$OutputObject = New-Object System.Collections.ArrayList

foreach ($User in $UKGMBUsers){
    $FTOutput = Get-Mailbox -Identity $User.mail | Get-MailboxStatistics | Select-Object DisplayName, IsArchiveMailbox, ItemCount, TotalItemSize 
    
    $TempObj = New-Object PSObject
    Add-Member -InputObject $TempObj -MemberType NoteProperty -Name DisplayName -Value $FTOutput.DisplayName
    Add-Member -InputObject $TempObj -MemberType NoteProperty -Name MailboxSize -Value $FTOutput.TotalItemSize
    Add-Member -InputObject $TempObj -MemberType NoteProperty -Name ItemCount -Value $FTOutput.ItemCount
    Add-Member -InputObject $TempObj -MemberType NoteProperty -Name IsArchiveMailbox -Value $FTOutput.IsArchiveMailbox
    
    $OutputObject.add($TempObj)|Out-Null
    # $FTOutput | Format-Table -AutoSize
}
$OutputObject | Out-GridView

#####
# Tidy up your mess
###
Remove-PSSession -Session $O365Session

﻿#####
#
# Get-OCMConfigBackups.ps1
#
# Author: Wayne Arliss - Wayne.Arliss@hfgplc.com
#
# Version: 1.0
#
#####
#
# Quick script to backup the XML config files for the OCMs at Laforey Road
#
##### 
# Setup
# Location of csv with OCM details in
$ImportPath   = '\\ukgmbsnas01\IT-Archive\SI OCM Backups\OCMs.csv'
# Location where to put the zip files
$ExportPath   = '\\ukgmbsnas01\IT-Archive\SI OCM Backups\'
#$ExportPath   = 'C:\TEMP\Test\' # Debug export location
# Location on OCM where config files are
$FileLocation = '\c$\Program Files (x86)\Systems Integration\OCM 15\'
$SettingsLocation = $FileLocation + 'Settings\*.*'
# What files to backup
$FileType     = '*.xml'
# Date for output zip file name
$FileDate     = Get-Date -Format "yyyyMMdd"

# Parse the import CSV file containing the OCM details
$SIOCM_Array  = Import-Csv -Path $ImportPath

## Progress bar variables
$TotalItems = $SIOCM_Array.Count
$CurrentItem = 0
$PercentComplete = 0

# The main loop
try{
    Foreach ($Device in $SIOCM_Array){
        Write-Progress -Activity "Backing Up OCM Configs" -Status "$PercentComplete Complete:" -PercentComplete $PercentComplete
        if (Test-Connection -ComputerName $Device.ComputerName -count 1 -Quiet){
            # OCM15 folder
            # Create Archive name and location
            $RemoteLocation = "\\" + ($Device.ComputerName) + $FileLocation + $FileType
            $ArchiveFileName = $ExportPath + $FileDate + "_" + ($Device.FriendlyName) + "_" + ($Device.ComputerName) + ".zip"
            # Create Zip File Archive
            Compress-Archive -Path $RemoteLocation -DestinationPath $ArchiveFileName

            # Settings Folder
            $RemoteLocation = "\\" + ($Device.ComputerName) + $SettingsLocation
            $ArchiveFileName = $ExportPath + $FileDate + "_" + ($Device.FriendlyName) + "_Settings_" + ($Device.ComputerName) + ".zip"
            # Create Zip File Archive
            Compress-Archive -Path $RemoteLocation -DestinationPath $ArchiveFileName

        }else{
            Write-Host $Device.ComputerName "Offline"
        }
        $CurrentItem++
        $PercentComplete = [int](($CurrentItem / $TotalItems) * 100)
    }
}
Catch{
    Write-Host "An Error Occurred"
    Write-Host $_
}
Finally{
    # Go home
}
﻿$UserBaseOU = 'OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$UserList = (Get-ADUser -Filter * -SearchBase $UserBaseOU).SamAccountName
$EndDate = (Get-Date)

ForEach ($User in $UserList){
    $StartDate = (Get-ADUser -Identity $User -Properties PasswordLastSet).PasswordLastSet
    
    if ($null -eq $StartDate){
        $StartDate = 9999
        $User
        $StartDate

    }
    $Diff = New-TimeSpan -Start $StartDate -End $EndDate
    $Age = ($Diff).Days.ToString()
    Write-Host "User: $User PasswordAge: $Age"
    }
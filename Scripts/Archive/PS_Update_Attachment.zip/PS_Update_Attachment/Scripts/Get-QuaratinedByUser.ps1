﻿#####
#
# Get-QuarantinedByUser.ps1
#
# Author: Wayne Arliss - Wayne.Arliss@hfgplc.com
#
# Version: 1.0  01/12/2022
#
#####
#
# Queries Microsoft Exchage Online for quarantied emails for users in the UKGMB OU in Active Directory
# Outputs a gridview list containing: User Email address, Date/Time received, Date/Time Expires, Senders email address and Subject
# Runs the search for previous 24 hours
#
#####
#
# Requires access to Exchange Online to run
#
#####

# Get User list from AD
$ADUserBase = "OU=Users,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com" # int.hiltonfoods.com/HFG/UKGMB/Users
$Users = Get-ADUser -SearchBase $ADUserBase -Filter * -Properties SamAccountName, mail
## $Users.mail - email addresses

# Connect to Exchange Online
$EXO_Cred = Get-Credential -Message 'Please enter your Exchange Online credentials'
Connect-ExchangeOnline -Credential $EXO_Cred

# Get quarantined messages between two dates
$Now = Get-Date
[System.DateTime]$StartDate = $Now.AddDays(-7) #"2022-11-30"
[System.DateTime]$EndDate = $Now.AddDays(-1) #"2022-12-1"

# Output object
$OutputData = New-Object System.Collections.ArrayList

foreach($User in $Users){
    if ($null -ne $User.mail){ #Check there is an email address for the user
        $QuarantinedMessages = Get-QuarantineMessage -StartReceivedDate $StartDate -EndReceivedDate $EndDate -ReleaseStatus 'NOTRELEASED' -PageSize 1000 -Page 1 -RecipientAddress ($User.mail)
        if ($QuarantinedMessages.Count -gt 0){
            Write-host $User.Name $QuarantinedMessages.Count
            # Not outputting a count to screen compile a CSV with some of the details in.
            foreach ($QMessage in $QuarantinedMessages){
                $CurrentUser = New-Object psobject
                # build temporary object to be added to the $OutputData final object
                Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name User -Value $QMessage.RecipientAddress
                Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Received -Value $QMessage.ReceivedTime
                Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Expires -Value $QMessage.Expires
                Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Sender -Value $QMessage.SenderAddress
                Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Subject -Value $QMessage.Subject
                #Add-Member -InputObject $CurrentUser -MemberType NoteProperty -Name Status -Value $QMessage.ReleasedStatus
            $OutputData.add($CurrentUser)|Out-Null
            }
        }
    }
}
$OutputData | Out-GridView

#foreach ($Message in $QuarantinedMessages){
#    Write-Host "Recipient:" ($Message.RecipientAddress) "Received:" ($Message.ReceivedTime) "Status:" ($Message.ReleaseStatus)
#}
﻿$Vowels = 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'
$Letters = 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z'
$Letters += 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Y', 'Z'
$SpecChar = '=', '_', '-', '@', '!'

$SmbServer = 'UKGMBSFS01'

#Sessions
$AllSmbSessions = Get-SmbSession -CimSession $SmbServer
#$AllSmbSessions | Get-Member -MemberType Property
<#
Get-SmbSession Properties returned

Name               MemberType Definition                      
----               ---------- ----------                      
ClientComputerName Property   string ClientComputerName {get;}
ClientUserName     Property   string ClientUserName {get;}    
ClusterNodeName    Property   string ClusterNodeName {get;}   
Dialect            Property   string Dialect {get;}           
NumOpens           Property   uint64 NumOpens {get;}          
PSComputerName     Property   string PSComputerName {get;}    
ScopeName          Property   string ScopeName {get;}         
SecondsExists      Property   uint32 SecondsExists {get;}     
SecondsIdle        Property   uint32 SecondsIdle {get;}       
SessionId          Property   uint64 SessionId {get;}         
TransportName      Property   string TransportName {get;}   
#>

#Open Files
$AllSmbOpenFiles = Get-SmbOpenFile -CimSession $SmbServer
#$AllSmbOpenFiles | Get-Member -MemberType Property
<#
Get-SmbOpenFiles Properties Returned

Name                  MemberType Definition                       
----                  ---------- ----------                       
ClientComputerName    Property   string ClientComputerName {get;}
ClientUserName        Property   string ClientUserName {get;}
ClusterNodeName       Property   string ClusterNodeName {get;}
ContinuouslyAvailable Property   bool ContinuouslyAvailable {get;}
Encrypted             Property   bool Encrypted {get;}
FileId                Property   uint64 FileId {get;}
Locks                 Property   uint32 Locks {get;}
Path                  Property   string Path {get;}
Permissions           Property   uint32 Permissions {get;}
PSComputerName        Property   string PSComputerName {get;}
ScopeName             Property   string ScopeName {get;}
SessionId             Property   uint64 SessionId {get;}
ShareRelativePath     Property   string ShareRelativePath {get;}
Signed                Property   bool Signed {get;}
#>

# Output the ShareRelativePath, USername, ClientComputerName
$AllSmbOpenFiles | Select-Object ShareRelativePath, ClientUserName, ClientComputerName | Sort-Object ShareRelativePath |
    Export-Csv -NoTypeInformation -Path 'C:\Users\Wayne.Arliss_UKGMBAD\Desktop\OpenFiles.csv'
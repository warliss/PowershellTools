﻿$InputFile = 'C:\TEMP\SageUsers_Cleaned.csv'
$SageUsers = Import-Csv -Path $InputFile #-Header 
$TotalUsers = $SageUsers.Count
$InactiveUsers = 0
$ADUsers = 0
$ToValidate = 0
$OutputObj = New-Object System.Collections.ArrayList
$ActiveFlag = $true

foreach ($SageUser in $SageUsers){
    $CurrentUser = New-Object PSObject # creates a temporary object to hold the details of the current server
    if ($SageUser.Active -eq ''){
        #Write-Host -ForegroundColor Red ($SageUser.Login) "Is inactive" $SageUser.Active
        $InactiveUsers ++
        $ActiveFlag = $false
        $ADAccount = 'Disabled'
        $ADStatus = ''
    }else{
        #Write-Host -ForegroundColor Green ($SageUser.Login) "Is active" $SageUser.Active
        try {
            $ActiveFlag = $true
            $CheckUser = Get-ADUser -Identity ($SageUser.'HFG-Account')
            if ($CheckUser){
                #Write-Host -ForegroundColor Green ($SageUser.Login) "Is active & in AD" $CheckUser.Name
                $ADAccount = $SageUser.'HFG-Account'
                $ADStatus = $CheckUser.Enabled
                $ADUsers ++
            }
        }catch [Microsoft.ActiveDirectory.Management.ADIdentityResolutionException]{
            #Write-Host -ForegroundColor Red ($SageUser.Login) "Is active but not in AD"
            $ADAccount = 'Needs Validating'
            $ADStatus = 'No account found with name'
            $ToValidate ++
        }catch {
            Write-Host -ForegroundColor Gray "Something broke" ($SageUser.Login)
        }
    }
    Add-Member -InputObject $CurrentUser -MemberType noteProperty -name SageLogin -value $SageUser.Login
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Title -value $SageUser.Title
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Firstname -value $SageUser.Firstname
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Lastname -value $SageUser.Lastname
    if (!$ActiveFlag){
        Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Active -value "FALSE"
    }else{
        Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Active -value $SageUser.Active
    }
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name Email -value $SageUser.EMail
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name ADAccount -value $ADAccount
    Add-Member -Inputobject $CurrentUser -MemberType noteProperty -name ADStatus -value $ADStatus
    $OutputObj.add($CurrentUser)|Out-Null
}

if ($InactiveUsers + $ADUsers + $ToValidate -eq $TotalUsers){
    Write-Host "Checks Passed"
    }else{
    Write-Host -ForegroundColor Gray "There's an error"
    }

Write-Host "Current Sage User Count:" $TotalUsers
Write-Host "Inactive Sage users:" $InactiveUsers
Write-Host "Sage users with AD Accounts:" $ADUsers
Write-Host "Sage Users to validate:" $ToValidate

﻿$ComputerName = "seachw176"
$Path = "\\" + $ComputerName + "\c$\Windows\System32\Tasks"
$Tasks = Get-ChildItem -Recurse -Path $Path -File
$OutputObj = New-Object System.Collections.ArrayList
foreach ($Task in $Tasks){
    $Details = "" | SELECT ComputerName,Task,User,Enabled,Application
    $AbsolutePath = $Task.directory.fullname + "\" + $Task.Name
    try{
        $TaskInfo = [xml](Get-Content $AbsolutePath)
        $Details.ComputerName = $ComputerName
        $Details.Task = $Task.Name
        $Details.User = $TaskInfo.task.principals.principal.userid
        $Details.Enabled = $TaskInfo.task.settings.enabled
        $Details.Application= $TaskInfo.task.actions.exec.command
    }
    catch {
        Write-Host $_
        $Details.ComputerName = $ComputerName
        $Details.Task = $Task.Name
        $Details.User = "Error"
        $Details.Enabled = "Error"
        $Details.Application= "Error"
    }
    finally{
        $OutputObj.add($Details)|Out-Null
    }
}
$OutputObj | FT -AutoSize
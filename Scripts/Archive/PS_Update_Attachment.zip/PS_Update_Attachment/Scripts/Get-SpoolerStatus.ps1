﻿#$ServerNames = Get-Content "C:\Users\Wayne.Arliss_UKGMBAD\Desktop\Servers.txt"

$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Servers
#$Base = 'OU=Production,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Omega Touchscreens
#$Base = 'OU=Workstations,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Workstations
$ServerNames = (Get-ADComputer -Filter * -SearchBase $Base).Name

foreach ($ServerName in $ServerNames){
    ## Test if remote computer is online
    if (Test-Connection -BufferSize 32 -Count 1 -ComputerName $ServerName -Quiet){
        $Colour = "Green"
        #Get-WmiObject -Class Win32_Service -Filter 'name="spooler"' -ComputerName $ServerName | Invoke-WmiMethod -Name StopService | Out-Null
        $Service = Get-Service -Name Spooler -ComputerName $ServerName
        if ($Service.Status -eq "Running"){
            $Colour = "Red"
        }
        Write-Host $Service.MachineName $Service.DisplayName $Service.Status $Service.StartType -ForegroundColor $Colour
    }else{
        Write-Host "$ServerName is Offline" -ForegroundColor Yellow
    }
}
﻿function Get-InstalledApps {
    param (
        [Parameter(ValueFromPipeline=$true)]
        [string[]]$ComputerName = $env:COMPUTERNAME,
        [string]$NameRegex = ''
    )
    
    foreach ($comp in $ComputerName) {
        $keys = '','\Wow6432Node'
        foreach ($key in $keys) {
            try {
                $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $comp)
                $apps = $reg.OpenSubKey("SOFTWARE$key\Microsoft\Windows\CurrentVersion\Uninstall").GetSubKeyNames()
            } catch {
                continue
            }

            foreach ($app in $apps) {
                $program = $reg.OpenSubKey("SOFTWARE$key\Microsoft\Windows\CurrentVersion\Uninstall\$app")
                $name = $program.GetValue('DisplayName')
                if ($name -and $name -match $NameRegex) {
                    [pscustomobject]@{
                        ComputerName = $comp
                        DisplayName = $name
                        DisplayVersion = $program.GetValue('DisplayVersion')
                        Publisher = $program.GetValue('Publisher')
                        InstallDate = $program.GetValue('InstallDate')
                        UninstallString = $program.GetValue('UninstallString')
                        Bits = $(if ($key -eq '\Wow6432Node') {'64'} else {'32'})
                        Path = $program.name
                    }
                }
            }
        }
    }
}

## Get a list of all computers in a specific OU
$BaseOU = 'OU=Workstations,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com'
$ComputerName = ((Get-ADComputer -Filter * -SearchBase $BaseOU -Properties Name).Name | Sort-Object Name)
#$ComputerName = "seachw117" # Uncomment and edit this to query specific computers

# Counter used to work out the percentage of the job that has been completed
$i = 1

#Output Object, this is displayed when the whole task has completed and can be manipulated afterwards
$OutputObj = New-Object System.Collections.ArrayList

foreach ($Computer in $ComputerName){
    $Details = "" | SELECT ComputerName,Status,Symantec
    $Details.ComputerName = $Computer
    $InstalledSoftware = ""
    $PercentComplete = [Math]::Round(($i / $ComputerName.Count * 100), 2)
    Write-Progress -Activity "Check Status: $Computer" -Status "Percent Complete: $PercentComplete" -PercentComplete $PercentComplete
    if (Test-Connection -ComputerName $Computer -Count 1 -Quiet){
        $Details.Status = "Online"
        Write-Progress -Activity "Online: $Computer" -Status "Percent Complete: $PercentComplete" -PercentComplete $PercentComplete
        $InstalledSoftware = Get-InstalledApps -ComputerName $Computer
        if ($InstalledSoftware.Publisher -contains "Symantec"){
            $Details.Symantec = "Installed"
        }else{
            $Details.Symantec = "Missing"
        }
    }else{
        Write-Progress -Activity "Offline: $Computer" -Status "Percent Complete: $PercentComplete" -PercentComplete $PercentComplete
        $Details.Status = "Offline"
        $Details.Symantec = "Unknown"
    }
    Write-Progress -Activity "Computer: $Computer" -Status "Percent Complete: $PercentComplete" -PercentComplete $PercentComplete
    $i++
    $OutputObj.add($Details)|Out-Null
}
$OutputObj | Export-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\symantec.csv -NoTypeInformation
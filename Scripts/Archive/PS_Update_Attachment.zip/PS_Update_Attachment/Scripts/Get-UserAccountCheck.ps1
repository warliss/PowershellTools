﻿$LeaverFile = "leavers.txt"
#$Leavers = "Lloyd.Tickle","Anna.Majsterek","Wayne.Arliss","Wayne.Arliss_UKGMBAD"
try {
    $Leavers = Get-Content -Path $LeaverFile -ErrorAction Stop # ErrorAction required as no file found doesn't stop the script from execuiting
    $Leavers.Length
    if ($Leavers.Length -eq 0){
        Write-Host "No users." #Do Nothing
    } else {
        foreach ($Leaver in $Leavers){
            $CurrentUser = "" # Resets the current user object to empty
            $OutputString = "" # Resets the OutputString object to empty
            try {
                $CurrentUser = Get-ADUser -Identity $Leaver -Properties *
                $OutputString = "User: " + $Leaver + " Email Address: " + $CurrentUser.UserPrincipalName + " Please ask HR to raise the ticket to have the user account removed."
                $colour = "Green"
            }
            catch [Microsoft.ActiveDirectory.Management.ADIdentityNotFoundException]{
                $OutputString = "No User Account for $Leaver"
                $colour = "Red"
            }
            catch {
                $OutputString = "Unknown error has occurred - useful I know... "
                $OutputString += "Occurred when searching user: " + $Leaver
                $colour = "Red"
            }
            finally {
                Write-Host $OutputString -ForegroundColor $colour 
            }
        }
    }
}
catch {
    Write-Host "Something went awry"
    Write-Host $Error.Exception.GetBaseException
}

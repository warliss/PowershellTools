﻿##
# Set up output details
$VMOutputObj = New-Object System.Collections.ArrayList

##
# Get credentials to be used 
$VMCredentials = Get-Credential -Message 'Please enter the account to access vSphere' # Uncomment first time running

##
# vSphere Server details
$vSphereServer = 'seavc.seachill.co.uk' # UKGMB LFR VSA vSphere
#$vSphereServer = 'ukgmbesvca01.int.hiltonfoods.com' # UKI SVT vSphere
# Connect to the vSphere server
$vSphereServerConnection = Connect-VIServer -Server $vSphereServer -Credential $VMCredentials

##
# Get all VMs
# What do I need:
#    Name, PowerState, NumCPU, MemoryMB, MemoryGB, VMHostId, Folder, Version, DataStoreIDList

$VMs = Get-VM -Server $vSphereServer

## Progress bar variables
$TotalItems = $VMs.Count
$CurrentItem = 0
$PercentComplete = 0

foreach ($VM in $VMs){
    Write-Progress -Activity "Querying VMs" -Status "$PercentComplete Complete:" -PercentComplete $PercentComplete
    $CurrentVM = New-Object PSObject # creates a temporary object to hold the details of the current VM
    $VMDetails = Get-VM -Name $VM 
    Add-Member -InputObject $CurrentVM -MemberType NoteProperty -Name Name -Value $VMDetails.Name
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name PowerState -value $VMDetails.PowerState
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name NumCPU -value $VMDetails.NumCPU
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name MemoryMB -value $VMDetails.MemoryMB
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name MemoryGB -value $VMDetails.MemoryGB
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name VMHost -value $VMDetails.VMHost
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name Folder -value $VMDetails.Folder
    #Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name Version -value $VMDetails.Version
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name Version -value $VMDetails.HardwareVersion
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name DataStoreCount -value $VMDetails.DataStoreIDList.Count
    $DataStoreList = New-Object System.Collections.ArrayList
    foreach ($disk in $VMDetails.DatastoreIdList){         
        $DataStoreList.add((Get-Datastore -Server $vSphereServer -id $disk).Name)|Out-Null
        }
    Add-Member -Inputobject $CurrentVM -MemberType noteProperty -name DataStoreList -value $DataStoreList
    $CurrentItem++
    $PercentComplete = [int](($CurrentItem / $TotalItems) * 100)
    $VMOutputObj.add($CurrentVM)|Out-Null
}
$VMOutputObj | Out-GridView
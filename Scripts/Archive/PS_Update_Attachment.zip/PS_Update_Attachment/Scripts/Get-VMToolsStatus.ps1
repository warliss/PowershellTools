﻿## Get-VMToolsStatus

# Get-VM | Get-VMGuest | Select VMName, PowerState, ToolsVersion # base command
# Get-VM | Get-VMGuest | Select VMName, State, OSFullName, HostName, ToolsVersion

# Connect to the vCenter Server - This will use the credentials of the user running it
Connect-VIServer -Server seavc.seachill.co.uk

# Get all the VMs 
$AllVMs = Get-VM

# Create the output object
$OutputObj = New-Object System.Collections.Arraylist

foreach ($CurrentVM in $AllVMs){
    $WorkingVM = New-Object psobject
    $CurrentVMDetail = $CurrentVM | Get-VMGuest | Select OSFullName, ToolsVersion, HardwareVersion
    
    # Build output object
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name VMName -Value $CurrentVM.Name
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name PowerState -Value $CurrentVM.PowerState
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name VMHost -Value $CurrentVM.VMHost.Name
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name FolderName -Value $CurrentVM.Folder.Name
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name OSFullName -Value $CurrentVMDetail.OSFullName
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name ToolsVersion -Value $CurrentVMDetail.ToolsVersion
    Add-Member -InputObject $WorkingVM -MemberType NoteProperty -Name HWVersion -Value $CurrentVM.HardwareVersion
    $OutputObj.add($WorkingVM)|Out-Null
}
#$OutputObj | Sort-Object FolderName, VMName | Export-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\VMTools-Details.csv -NoTypeInformation
$OutputObj | Sort-Object FolderName, VMName | Out-GridView
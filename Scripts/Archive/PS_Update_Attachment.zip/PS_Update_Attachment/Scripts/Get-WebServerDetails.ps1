﻿# Get computer list from AD
#$Base = 'OU=Servers,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## UKGMB Servers 
#$Base = 'OU=Servers,OU=HFGIE,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## IEDRG Servers 
#$Base = 'OU=Production,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' ## Omega Touchscreens
#$ServerList = Get-ADComputer -Filter "Enabled -eq '$true'" -SearchBase $Base -Properties Name, OperatingSystem, Description, Enabled | Sort-Object Name

## Temp small list of servers
$ServerList = Import-Csv -Path 'servers.csv'

$IISReport = New-Object System.Collections.ArrayList # Create the new output object
## Check if each server is online
$i = 1
foreach ($Server in $ServerList){
    if ($true -eq $Server.Enabled){
        if (Test-Connection -ComputerName $Server.Name -Quiet -Count 1){ # Online
            $IISInfo = $null
            $StartTime = $(Get-Date)
            Write-Host $i $Server.Name
            $i++
            try{
                $IISInfo = Get-WindowsFeature -Name "Web-Server" -ComputerName $Server.Name -ErrorAction Stop
            }
            catch{
                $Message = $_
                Write-Warning $Message
            }
            $CurrentServer = New-Object PSObject # creates a temporary object to hold the details of the current server
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name ComputerName -Value $Server.Name
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name IISInstalled -Value $IISInfo.Installed
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name IISState -Value $IISInfo.InstallState
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name IISName -Value $IISInfo.Name
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name IISDescription -Value $IISInfo.Descrition
            $ElapsedTime = $(Get-Date) - $StartTime
            $TotalTime = "{0:HH:mm:ss}" -f ([Datetime]$ElapsedTime.Ticks)
            Add-Member -InputObject $CurrentServer -MemberType NoteProperty -Name TimeTaken -Value $TotalTime
            $IISReport.add($CurrentServer)|Out-Null 
        }
    }
}
$IISReport | Out-GridView
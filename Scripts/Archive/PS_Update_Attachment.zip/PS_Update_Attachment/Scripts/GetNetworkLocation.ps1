﻿<# list all enabled PCs in workstation OU
$Computers = Get-ADComputer -Filter * -Properties OperatingSystem, Description -SearchBase 'OU=Workstations,OU=UKGMB,OU=HFG,DC=int,DC=hiltonfoods,DC=com' | Sort-Object Name, Description, OperatingSystem
Foreach ($Computer in $Computers){
    $CompName = $Computer.Name
    $CompOS = $Computer.OperatingSystem    
    $CompDesc = $Computer.Description
    Write-Host("Computer: $CompName OS: $CompOS Description: $CompDesc")
}#>


<#
$State = Test-Connection -ComputerName SEACHW030 -Count 1
$State.Address
$State.IPV4Address
#>

$OutputObj = New-Object System.Collections.ArrayList
$CSVContent = Import-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\Win10Pro.csv
$CSVContent.Count
Foreach ($Computer in ($CSVContent.Computer)){
    $CurrentComputer = New-Object PSObject # creates a temporary object to hold the details of the current server
    $Online = Test-Connection -ComputerName $Computer -Count 1
    $IPAddress = ""
    $Location = ""
    if ($Online){
        $State = "Online"
        $IPAddress = $Online.IPV4Address.ToString()
        if ($Online.IPV4Address.GetAddressBytes()[1] -eq 7){ 
            $Location = "Home" 
        }else{
            $Location = "Unknown.."
            switch ($Online.IPV4Address.GetAddressBytes()[2]){
                128 {$Location = "ER2 Wired"}
                134 {$Location = "ER2 Corp WiFi"}
                135 {$Location = "ER2 Guest WiFi"}
                136 {$Location = "ER2 Canteen WiFi"}
                137 {$Location = "ER2 Factory WiFi"}
                145 {$Location = "ER2 Cert WiFi"}
                148 {$Location = "LFR Wired"}
                154 {$Location = "LFR Corp WiFi"}
                155 {$Location = "LFR Guest WiFi"}
                156 {$Location = "LFR Canteen WiFi"}
                157 {$Location = "LFR Factory WiFi"}
                165 {$Location = "LFR Cert WiFi"}
                166 {$Location = "LFR Mach WiFi"}
                45 {$Location = "LFR Old Data"}
                default {$Location = "Unknown"}
            }
        }
        
    }else{
        $State = "Offline"
        $IPAddress = "n/a"
        $Location = "n/a"
    }
    Add-Member -InputObject $CurrentComputer -MemberType NoteProperty -Name Name -Value $Computer
    Add-Member -Inputobject $CurrentComputer -MemberType noteProperty -name IPAddress -value $IPAddress
    Add-Member -InputObject $CurrentComputer -MemberType NoteProperty -Name State -Value $State
    Add-Member -InputObject $CurrentComputer -MemberType NoteProperty -Name Location -Value $Location
    $OutputObj.add($CurrentComputer)|Out-Null
}
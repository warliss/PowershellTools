﻿$ComputerName = Read-Host 'Computer Name' # Get the computer name
$LAPSPassword = Get-AdmPwdPassword -ComputerName $ComputerName | Select Password # Get the Local Admin password
Set-Clipboard -Value $LAPSPassword.Password # Copy the password to the clipboard
$LAPSPassword

﻿$Sender = "Wayne.Arliss@hfgplc.com" # Change to whatever email address you need
$Recipient = "Wayne.Arliss@hfgplc.com" # Who to send the email to
$Subject = "Test email " 
$SMTPServer = "UKGMBSSMTP01"
$Body = "This is another simple test" # This can be the output from any query or script as long as it is in string format.

Send-MailMessage -SmtpServer $SMTPServer -Subject $Subject -To $Recipient -From $Sender -Body $Body
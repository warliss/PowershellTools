﻿function Send-WOL
{
<#
    .SYNOPSIS
    Send a WOL packet to a broadcast address
    .PARAMETER mac
    The MAC address of the device that needs to wake up
    .PARAMETER ip
    The IP address where the WOL packet will be sent to
    .EXAMPLE
    Send-WOL -mac 00:11:22:33:44:55 -ip 192.168.45.255
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true,Position=1)]
    [string]$mac,
    [string]$ip="255.255.255.255",
    [int]$port=9
    )
$Broadcast = [Net.IPAddress]::Parse($ip)
$mac = (($mac.Replace(":","")).Replace("-","")).Replace(".","")
$target=0,2,4,6,8,10 | % {[Convert]::ToByte($mac.Substring($_,2),16)}
$packet = (,[byte]255 * 6) + ($target * 16)

$UDPclient = New-Object System.Net.Sockets.UdpClient
$UDPclient.Connect($Broadcast,$port)
[void]$UDPclient.Send($packet, 102)
}
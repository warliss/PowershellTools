﻿# Connect to VSphere server
#Connect-VIServer -Server seavc.seachill.co.uk 

# Create output object
$OutputObj = New-Object System.Collections.ArrayList
$ds = Get-Datastore -Name NVD* | Sort-Object Name
foreach ($d in $ds){
    $VM = Get-VM -Datastore $d
    if (($VM.Name) -is [Array]){
        foreach ($a in $VM){
            $UsedSpace = $d.CapacityGB - $d.FreeSpaceGB
            $CurrentDS = New-Object psobject
            Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name Name -Value $d.Name
            Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name CapacityGB -Value $d.CapacityGB
            Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name FreeSpaceGB -Value $d.FreeSpaceGB
            Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name UsedSpaceGB -Value $UsedSpace
            Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name VMName -Value $a.Name
            $OutputObj.add($CurrentDS)|Out-Null
        } 
    } else {
        $UsedSpace = $d.CapacityGB - $d.FreeSpaceGB
        $CurrentDS = New-Object psobject
        Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name Name -Value $d.Name
        Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name CapacityGB -Value $d.CapacityGB
        Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name FreeSpaceGB -Value $d.FreeSpaceGB
        Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name UsedSpaceGB -Value $UsedSpace
        Add-Member -InputObject $CurrentDS -MemberType NoteProperty -Name VMName -Value $VM.Name
        $OutputObj.add($CurrentDS)|Out-Null
    }
}

    $OutputObj | Export-Csv -Path C:\Users\Wayne.Arliss_UKGMBAD\Desktop\20201007DatastoresInUse.csv -NoTypeInformation #| Out-GridView